export default function FacebookTab() {
  return (
    <div className="text-white text-xl">Facebook Bereich</div>
  );
}