export default function MerchTab() {
  return (
    <div className="text-white text-xl">Merch Bereich</div>
  );
}