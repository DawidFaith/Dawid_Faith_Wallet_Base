export default function TiktokTab() {
  return (
    <div className="text-white text-xl">TikTok Bereich</div>
  );
}