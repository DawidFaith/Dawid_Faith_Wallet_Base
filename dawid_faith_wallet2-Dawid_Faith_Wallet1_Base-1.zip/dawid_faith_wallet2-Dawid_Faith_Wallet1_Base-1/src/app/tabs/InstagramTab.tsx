export default function InstagramTab() {
  return (
    <div className="text-white text-xl">Instagram Bereich</div>
  );
}