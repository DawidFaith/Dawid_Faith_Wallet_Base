export default function StreamTab() {
  return (
    <div className="text-white text-xl">Stream Bereich</div>
  );
}