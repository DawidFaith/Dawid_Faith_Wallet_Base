export default function TokenomicsTab() {
  return (
    <div className="text-white text-xl">Tokenomics Bereich</div>
  );
}