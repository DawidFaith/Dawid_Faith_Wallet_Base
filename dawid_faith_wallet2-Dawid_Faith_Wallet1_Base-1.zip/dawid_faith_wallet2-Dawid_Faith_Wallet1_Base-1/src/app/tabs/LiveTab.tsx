export default function LiveTab() {
  return (
    <div className="text-white text-xl">Live Bereich und</div>
  );
}